package com.codingdojo.mostrar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MostrarApplicationTests {

	@Test
	void contextLoads() {
	}

}
