package com.codingdojo.mostrarlafecha;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MostrarlafechaApplicationTests {

	@Test
	void contextLoads() {
	}

}
