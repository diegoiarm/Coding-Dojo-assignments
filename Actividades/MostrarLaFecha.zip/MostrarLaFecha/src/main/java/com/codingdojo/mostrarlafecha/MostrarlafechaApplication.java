package com.codingdojo.mostrarlafecha;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MostrarlafechaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MostrarlafechaApplication.class, args);
	}

}
