package com.codingdojo.actualizaryeliminar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ActualizaryeliminarApplication {

	public static void main(String[] args) {
		SpringApplication.run(ActualizaryeliminarApplication.class, args);
	}

}
