package com.codingdojo.actualizaryeliminar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ActualizaryeliminarApplicationTests {

	@Test
	void contextLoads() {
	}

}
