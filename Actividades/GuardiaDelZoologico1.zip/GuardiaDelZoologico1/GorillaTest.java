package com.codingdojo.guardiazoo1;

public class GorillaTest {

	public static void main(String[] args) {
		Gorilla g = new Gorilla();
		g.displayEnergy();
		g.throwSomething();
		g.eatBananas();
		g.climb();
		g.displayEnergy();

	}

}
