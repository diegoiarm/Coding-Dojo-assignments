package com.codingdojo.calculadorauno;

public class CalculatorTest {

	public static void main(String[] args) {
		Calculator c = new Calculator();
		c.performOperation();
	}

}
