package com.codingdojo.maestrodeobjetos;

public class HumanTest {

	public static void main(String[] args) {

		Human human = new Human();
		System.out.println(human.attack(human));
		

	}

}
